package oop;
public enum Alliance {
    REBELS,
    EMPIRE;
}
//
//    private String allianceName;
//    Alliance(String allianceName) {
//        this.allianceName = allianceName;
//    }
//
//    public static Alliance textValueOf(String textValue){
//
//        for(Alliance value : values()) {
//            if(value.allianceName.equals(textValue)) {
//                return value;
//            }
//        }
//
//        throw new IllegalArgumentException("No EnumWithValueOf for value: " + textValue);
//    }





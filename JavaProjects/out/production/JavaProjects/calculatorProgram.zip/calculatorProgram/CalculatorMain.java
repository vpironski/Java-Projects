package calculatorProgram;

public class CalculatorMain {
    public static void main(String[] args) {
        new Calculator();
    }
}
